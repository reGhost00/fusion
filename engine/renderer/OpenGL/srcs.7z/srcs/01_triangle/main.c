#include <mimalloc.h>
#include <stdio.h>
#include <stdlib.h>
#define FU_USE_GLFW

#ifdef FU_USE_GLFW
#define FU_USE_GLAD
#ifdef FU_USE_GLAD
#include <glad/vulkan.h>
#define GLFW_INCLUDE_NONE
#else
#define GLFW_INCLUDE_VULKAN
#endif
#include <GLFW/glfw3.h>
typedef GLFWwindow RawWindow;
#else
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
#include <SDL2/SDL_vulkan.h>
#include <vulkan/vulkan.h>
typedef SDL_Window RawWindow;
#endif
#define DEF_WIN_WIDTH 800
#define DEF_WIN_HEIGHT 600
#define FU_N_ELEMENTS(x) (sizeof(x) / sizeof((x)[0]))

#define fu_max(a, b) (a > b ? a : b)
#define fu_min(a, b) (a < b ? a : b)
#define fu_error(format, ...) fprintf(stderr, "\033[91;49m" format "\033[0m", ##__VA_ARGS__);
#define fu_warning(format, ...) fprintf(stderr, "\033[93;49m" format "\033[0m", ##__VA_ARGS__);
#define fu_info(format, ...) fprintf(stderr, "\033[92;49m" format "\033[0m", ##__VA_ARGS__);

static void* _vk_malloc(void* usd, size_t size, size_t alignment, VkSystemAllocationScope scope) { return mi_aligned_alloc(alignment, size); }
static void* _vk_realloc(void* usd, void* p, size_t size, size_t alignment, VkSystemAllocationScope scope) { return mi_aligned_recalloc(p, 1, size, alignment); }
static void _vk_free(void* usd, void* p) { mi_free(p); }

static VkAllocationCallbacks defCustomAllocator = {
    .pfnAllocation = _vk_malloc,
    .pfnReallocation = _vk_realloc,
    .pfnFree = _vk_free
};

typedef struct _TVertex {
    float position[3];
    float color[4];
} TVertex;

static const TVertex vertices[] = {
    { { 0.0f, -0.5f }, { 1.0f, 0.0f, 0.0f, 1.0f } },
    { { 0.5f, 0.5f }, { 0.0f, 1.0f, 0.0f, 1.0f } },
    { { -0.5f, 0.5f }, { 0.0f, 0.0f, 1.0f, 1.0f } },
};

#define t_vertex_binding_free(binding) mi_free(binding)
VkVertexInputBindingDescription* t_vertex_get_binding()
{
    VkVertexInputBindingDescription* binding = mi_zalloc(sizeof(VkVertexInputBindingDescription));
    binding->stride = sizeof(TVertex);
    binding->inputRate = VK_VERTEX_INPUT_RATE_VERTEX;
    return binding;
}

#define t_vertex_description_free(desc) mi_free(desc)
VkVertexInputAttributeDescription* t_vertex_get_description(uint32_t* count)
{
    VkVertexInputAttributeDescription* desc = mi_calloc(2, sizeof(VkVertexInputAttributeDescription));
    desc[0].format = VK_FORMAT_R32G32B32_SFLOAT;
    desc[1].location = 1;
    desc[1].format = VK_FORMAT_R32G32B32A32_SFLOAT;
    desc[1].offset = offsetof(TVertex, color);
    *count = 2;
    return desc;
}

typedef struct _TImage {
    VkImage image;
    VkImageView view;
} TImage;

typedef struct _TBuffer {
    VkBuffer buffer;
    VkDeviceMemory memory;
} TBuffer;

typedef struct _TSync {
    VkSemaphore* imageAvailable;
    VkSemaphore* renderFinished;
    VkFence* inFlight;
} TSync;

typedef struct _TDrawing {
    TBuffer vertexBuffer;
    VkCommandPool commandPool;
    VkCommandBuffer* commandBuffers;
    VkFramebuffer* framebuffers;
    uint32_t framebufferCount;
} TDrawing;
#define T_FRAMEBUFFER(app) (app->drawing.framebuffers)
#define T_CMD_POOL(app) (app->drawing.commandPool)
#define T_CMD_BUFF(app) (app->drawing.commandBuffers)
#define T_VERTEX_BUFFER(app) (app->drawing.vertexBuffer)
//
//
typedef struct _TPipeline {
    VkPipeline pipeline;
    VkPipelineLayout layout;
    VkRenderPass renderPass;
} TPipeline;
#define T_RENDER_PASS(app) (app->pipeline.renderPass)
#define T_PIPELINE_LAYOUT(app) (app->pipeline.layout)
#define T_PIPELINE(app) (app->pipeline.pipeline)

typedef struct _TSwapchain {
    VkSwapchainKHR swapchain;
    TImage* images;
    uint32_t imageCount;
    bool outOfDate;
} TSwapchain;
#define T_SWAPCHAIN(app) (app->swapchain.swapchain)
#define T_SWAPCHAIN_IMAGES(app) (app->swapchain.images)

typedef struct _TQueueFamilyProperties {
    VkQueueFamilyProperties properties;
    uint32_t index;
    bool presentSupported;
} TQueueFamilyProperties;

typedef struct _TPhysicalDevice {
    VkPhysicalDevice physicalDevice;
    VkPhysicalDeviceFeatures features;
    VkPhysicalDeviceProperties properties;
    VkExtensionProperties* extensions;
    TQueueFamilyProperties* queueFamilies;
    TQueueFamilyProperties* graphicsQueueFamilies;
    TQueueFamilyProperties* computeQueueFamilies;
    TQueueFamilyProperties* transferQueueFamilies;
    uint32_t extensionCount, queueFamilyCount, graphicsQueueFamilyCount, computeQueueFamilyCount, transferQueueFamilyCount;
} TPhysicalDevice;
#define T_PHYSICAL_DEVICE(app) (app->device.physicalDevice.physicalDevice)

typedef struct _TDevice {
    TPhysicalDevice physicalDevice;
    VkDevice device;
    VkQueue generalQueue;
    uint32_t queueFamilyIndex;
} TDevice;
#define T_DEVICE(app) (app->device.device)
#define T_QUEUE(app) (app->device.generalQueue)

typedef struct _TSurfaceDetail {
    VkSurfaceCapabilitiesKHR capabilities;
    VkSurfaceFormatKHR* format;
    VkPresentModeKHR* presentMode;
    uint32_t formatCount, presentModeCount;
} TSurfaceDetail;

typedef struct _TSurface {
    VkSurfaceKHR surface;
    VkSurfaceCapabilitiesKHR capabilities;
    VkSurfaceFormatKHR format;
    VkPresentModeKHR presentMode;
    VkExtent2D extent;
    RawWindow* window;
} TSurface;
#define T_SURFACE(app) (app->surface.surface)
#define T_WINDOW(app) (app->surface.window)

typedef struct _TApp {
    TSync sync;
    TDrawing drawing;
    TPipeline pipeline;
    TSwapchain swapchain;
    TDevice device;
    TSurface surface;
    VkInstance instance;
    VkDebugUtilsMessengerEXT debugger;
} TApp;
//
//  common
#ifndef FU_USE_GLAD
static struct _vk_fns_t {
    PFN_vkCreateDebugUtilsMessengerEXT vkCreateDebugUtilsMessengerEXT;
    PFN_vkDestroyDebugUtilsMessengerEXT vkDestroyDebugUtilsMessengerEXT;
} vkfns;

void tvk_fns_init_instance(VkInstance instance)
{
    vkfns.vkCreateDebugUtilsMessengerEXT = (PFN_vkCreateDebugUtilsMessengerEXT)vkGetInstanceProcAddr(instance, "vkCreateDebugUtilsMessengerEXT");
    vkfns.vkDestroyDebugUtilsMessengerEXT = (PFN_vkDestroyDebugUtilsMessengerEXT)vkGetInstanceProcAddr(instance, "vkDestroyDebugUtilsMessengerEXT");
}

VkResult vkCreateDebugUtilsMessengerEXT(VkInstance inst, const VkDebugUtilsMessengerCreateInfoEXT* info, const VkAllocationCallbacks* cb, VkDebugUtilsMessengerEXT* debugger)
{
    return vkfns.vkCreateDebugUtilsMessengerEXT(inst, info, cb, debugger);
}

void vkDestroyDebugUtilsMessengerEXT(VkInstance inst, VkDebugUtilsMessengerEXT debugger, const VkAllocationCallbacks* cb)
{
    vkfns.vkDestroyDebugUtilsMessengerEXT(inst, debugger, cb);
}
#endif

uint32_t tvk_find_memory_type(VkPhysicalDevice device, uint32_t typeFilter, VkMemoryPropertyFlags properties)
{
    VkPhysicalDeviceMemoryProperties memProperties;
    vkGetPhysicalDeviceMemoryProperties(device, &memProperties);

    for (uint32_t i = 0; i < memProperties.memoryTypeCount; i++) {
        if ((typeFilter & (1 << i)) && (memProperties.memoryTypes[i].propertyFlags & properties) == properties) {
            return i;
        }
    }

    fu_error("failed to find suitable memory type!");
    return ~0UL;
}

void* fu_memdup(const void* mem, size_t size)
{
    if (!(mem && size))
        return NULL;
    void* dest = mi_malloc(size);
    memcpy(dest, mem, size);
    return dest;
}

static inline void* fu_steal_pointer(void* pp)
{
    void** ptr = (void**)pp;
    void* ref;

    ref = *ptr;
    *ptr = NULL;

    return ref;
}
#define fu_steal_pointer(pp) ((typeof(*pp))(fu_steal_pointer)(pp))
//
//  Sync

static void t_app_destroy_sync(TApp* app)
{
    for (uint32_t i = 0; i < app->swapchain.imageCount; i++) {
        vkDestroySemaphore(T_DEVICE(app), app->sync.imageAvailable[i], &defCustomAllocator);
        vkDestroySemaphore(T_DEVICE(app), app->sync.renderFinished[i], &defCustomAllocator);
        vkDestroyFence(T_DEVICE(app), app->sync.inFlight[i], &defCustomAllocator);
    }
    mi_free(app->sync.imageAvailable);
    mi_free(app->sync.renderFinished);
    mi_free(app->sync.inFlight);
}

static bool t_app_init_sync(TApp* app)
{
    VkSemaphoreCreateInfo semaphoreInfo = {
        .sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO
    };
    VkFenceCreateInfo fenceInfo = {
        .sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO,
        .flags = VK_FENCE_CREATE_SIGNALED_BIT
    };
    bool rev = false;
    app->sync.imageAvailable = (VkSemaphore*)mi_calloc(app->swapchain.imageCount, sizeof(VkSemaphore));
    app->sync.renderFinished = (VkSemaphore*)mi_calloc(app->swapchain.imageCount, sizeof(VkSemaphore));
    app->sync.inFlight = (VkFence*)mi_calloc(app->swapchain.imageCount, sizeof(VkFence));
    for (uint32_t i = 0; i < app->swapchain.imageCount; i++) {
        rev = !vkCreateSemaphore(T_DEVICE(app), &semaphoreInfo, &defCustomAllocator, &app->sync.imageAvailable[i]);
        rev = rev && !vkCreateSemaphore(T_DEVICE(app), &semaphoreInfo, &defCustomAllocator, &app->sync.renderFinished[i]);
        rev = rev && !vkCreateFence(T_DEVICE(app), &fenceInfo, &defCustomAllocator, &app->sync.inFlight[i]);
        if (!rev)
            return false;
    }

    return rev;
}

//
//  drawing stuff
static void t_app_destroy_buffers(TApp* app)
{
    for (uint32_t i = 0; i < app->drawing.framebufferCount; i++)
        vkDestroyFramebuffer(T_DEVICE(app), T_FRAMEBUFFER(app)[i], &defCustomAllocator);
    vkDestroyCommandPool(T_DEVICE(app), T_CMD_POOL(app), &defCustomAllocator);
    vkDestroyBuffer(T_DEVICE(app), T_VERTEX_BUFFER(app).buffer, &defCustomAllocator);
    vkFreeMemory(T_DEVICE(app), T_VERTEX_BUFFER(app).memory, &defCustomAllocator);
    mi_free(T_FRAMEBUFFER(app));
    app->drawing.framebufferCount = 0;
}

static bool t_app_init_buffers__framebuffers(TApp* app)
{
    VkImageView attachments[] = { NULL };
    VkFramebufferCreateInfo framebufferInfo = {
        .sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO,
        .renderPass = T_RENDER_PASS(app),
        .attachmentCount = 1,
        .pAttachments = attachments,
        .width = app->surface.extent.width,
        .height = app->surface.extent.height,
        .layers = 1
    };
    app->drawing.framebufferCount = app->swapchain.imageCount;
    for (uint32_t i = 0; i < app->drawing.framebufferCount; i++) {
        attachments[0] = T_SWAPCHAIN_IMAGES(app)[i].view;
        if (vkCreateFramebuffer(T_DEVICE(app), &framebufferInfo, &defCustomAllocator, &T_FRAMEBUFFER(app)[i])) {
            fu_error("Failed to create framebuffer\n");
            return false;
        }
    }

    return true;
}

static bool t_app_init_buffers__vertex(TApp* app)
{
    VkBufferCreateInfo bufferInfo = {
        .sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
        .size = sizeof(vertices),
        .usage = VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
        .sharingMode = VK_SHARING_MODE_EXCLUSIVE
    };
    if (vkCreateBuffer(T_DEVICE(app), &bufferInfo, &defCustomAllocator, &T_VERTEX_BUFFER(app).buffer)) {
        fu_error("Failed to create vertex buffer");
        return false;
    }

    VkMemoryRequirements memReq;
    vkGetBufferMemoryRequirements(T_DEVICE(app), T_VERTEX_BUFFER(app).buffer, &memReq);

    VkMemoryAllocateInfo allocInfo = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
        .allocationSize = memReq.size,
        .memoryTypeIndex = tvk_find_memory_type(T_PHYSICAL_DEVICE(app), memReq.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)
    };
    if (vkAllocateMemory(T_DEVICE(app), &allocInfo, &defCustomAllocator, &T_VERTEX_BUFFER(app).memory)) {
        fu_error("Failed to alloate vertex buffer memory");
        return false;
    }

    void* data;
    vkBindBufferMemory(T_DEVICE(app), T_VERTEX_BUFFER(app).buffer, T_VERTEX_BUFFER(app).memory, 0);
    vkMapMemory(T_DEVICE(app), T_VERTEX_BUFFER(app).memory, 0, bufferInfo.size, 0, &data);
    memcpy(data, vertices, bufferInfo.size);
    vkUnmapMemory(T_DEVICE(app), T_VERTEX_BUFFER(app).memory);
    return true;
}

static bool t_app_init_buffers(TApp* app)
{

    T_FRAMEBUFFER(app) = mi_calloc(app->swapchain.imageCount, sizeof(VkFramebuffer));
    if (!t_app_init_buffers__framebuffers(app))
        return false;
    if (!t_app_init_buffers__vertex(app))
        return false;
    VkCommandPoolCreateInfo poolInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
        .flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT,
        .queueFamilyIndex = app->device.queueFamilyIndex,
    };
    if (vkCreateCommandPool(T_DEVICE(app), &poolInfo, &defCustomAllocator, &T_CMD_POOL(app))) {
        fu_error("Failed to create command pool\n");
        return false;
    }

    VkCommandBufferAllocateInfo allocInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
        .commandPool = T_CMD_POOL(app),
        .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
        .commandBufferCount = app->swapchain.imageCount
    };
    T_CMD_BUFF(app) = mi_calloc(app->swapchain.imageCount, sizeof(VkCommandBuffer));
    if (vkAllocateCommandBuffers(T_DEVICE(app), &allocInfo, T_CMD_BUFF(app))) {
        fu_error("Failed to allocate command buffers\n");
        return false;
    }
    return true;
}

static bool t_command_buffer_recording(TApp* app, VkCommandBuffer cmdf, uint32_t imageIndex)
{
    VkCommandBufferBeginInfo beginInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
        // .flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT,
        .pInheritanceInfo = NULL
    };
    if (vkBeginCommandBuffer(cmdf, &beginInfo)) {
        fu_error("Failed to begin recording command buffer\n");
        return false;
    }
    static const VkClearValue clearColor = { { { 0.0f, 0.0f, 0.0f, 1.0f } } };
    VkRenderPassBeginInfo renderPassInfo = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
        .renderPass = T_RENDER_PASS(app),
        .framebuffer = T_FRAMEBUFFER(app)[imageIndex],
        .renderArea = {
            .extent = app->surface.extent },
        .clearValueCount = 1,
        .pClearValues = &clearColor
    };
    vkCmdBeginRenderPass(cmdf, &renderPassInfo, VK_SUBPASS_CONTENTS_INLINE);
    vkCmdBindPipeline(cmdf, VK_PIPELINE_BIND_POINT_GRAPHICS, T_PIPELINE(app));

    VkViewport viewport = {
        .width = (float)app->surface.extent.width,
        .height = (float)app->surface.extent.height,
        .maxDepth = 1.0f
    };
    VkRect2D scissor = {
        .extent = app->surface.extent
    };
    VkBuffer vertexBuffer[] = { T_VERTEX_BUFFER(app).buffer };
    VkDeviceSize offsets[] = { 0 };
    vkCmdSetViewport(cmdf, 0, 1, &viewport);
    vkCmdSetScissor(cmdf, 0, 1, &scissor);
    vkCmdBindVertexBuffers(cmdf, 0, 1, vertexBuffer, offsets);

    vkCmdDraw(cmdf, FU_N_ELEMENTS(vertices), 1, 0, 0);

    vkCmdEndRenderPass(cmdf);
    if (vkEndCommandBuffer(cmdf)) {
        fu_error("Failed to record command buffer\n");
        return false;
    }
    return true;
}

//
//  pipeline

static void t_app_destroy_pipeline(TApp* app)
{
    vkDestroyPipeline(T_DEVICE(app), T_PIPELINE(app), &defCustomAllocator);
    vkDestroyPipelineLayout(T_DEVICE(app), T_PIPELINE_LAYOUT(app), &defCustomAllocator);
    vkDestroyRenderPass(T_DEVICE(app), T_RENDER_PASS(app), &defCustomAllocator);
}

static bool t_app_init_pipeline__graphics_pipeline(TApp* app)
{
    const uint32_t shaderVertCode[] = {
        0x07230203, 0x00010600, 0x0008000b, 0x0000001f, 0x00000000, 0x00020011, 0x00000001, 0x0006000b,
        0x00000001, 0x4c534c47, 0x6474732e, 0x3035342e, 0x00000000, 0x0003000e, 0x00000000, 0x00000001,
        0x0009000f, 0x00000000, 0x00000004, 0x6e69616d, 0x00000000, 0x0000000d, 0x00000012, 0x0000001b,
        0x0000001d, 0x00030003, 0x00000002, 0x000001cc, 0x00040005, 0x00000004, 0x6e69616d, 0x00000000,
        0x00060005, 0x0000000b, 0x505f6c67, 0x65567265, 0x78657472, 0x00000000, 0x00060006, 0x0000000b,
        0x00000000, 0x505f6c67, 0x7469736f, 0x006e6f69, 0x00070006, 0x0000000b, 0x00000001, 0x505f6c67,
        0x746e696f, 0x657a6953, 0x00000000, 0x00070006, 0x0000000b, 0x00000002, 0x435f6c67, 0x4470696c,
        0x61747369, 0x0065636e, 0x00070006, 0x0000000b, 0x00000003, 0x435f6c67, 0x446c6c75, 0x61747369,
        0x0065636e, 0x00030005, 0x0000000d, 0x00000000, 0x00050005, 0x00000012, 0x6f506e69, 0x69746973,
        0x00006e6f, 0x00050005, 0x0000001b, 0x67617266, 0x6f6c6f43, 0x00000072, 0x00040005, 0x0000001d,
        0x6f436e69, 0x00726f6c, 0x00050048, 0x0000000b, 0x00000000, 0x0000000b, 0x00000000, 0x00050048,
        0x0000000b, 0x00000001, 0x0000000b, 0x00000001, 0x00050048, 0x0000000b, 0x00000002, 0x0000000b,
        0x00000003, 0x00050048, 0x0000000b, 0x00000003, 0x0000000b, 0x00000004, 0x00030047, 0x0000000b,
        0x00000002, 0x00040047, 0x00000012, 0x0000001e, 0x00000000, 0x00040047, 0x0000001b, 0x0000001e,
        0x00000000, 0x00040047, 0x0000001d, 0x0000001e, 0x00000001, 0x00020013, 0x00000002, 0x00030021,
        0x00000003, 0x00000002, 0x00030016, 0x00000006, 0x00000020, 0x00040017, 0x00000007, 0x00000006,
        0x00000004, 0x00040015, 0x00000008, 0x00000020, 0x00000000, 0x0004002b, 0x00000008, 0x00000009,
        0x00000001, 0x0004001c, 0x0000000a, 0x00000006, 0x00000009, 0x0006001e, 0x0000000b, 0x00000007,
        0x00000006, 0x0000000a, 0x0000000a, 0x00040020, 0x0000000c, 0x00000003, 0x0000000b, 0x0004003b,
        0x0000000c, 0x0000000d, 0x00000003, 0x00040015, 0x0000000e, 0x00000020, 0x00000001, 0x0004002b,
        0x0000000e, 0x0000000f, 0x00000000, 0x00040017, 0x00000010, 0x00000006, 0x00000003, 0x00040020,
        0x00000011, 0x00000001, 0x00000010, 0x0004003b, 0x00000011, 0x00000012, 0x00000001, 0x0004002b,
        0x00000006, 0x00000014, 0x3f800000, 0x00040020, 0x00000019, 0x00000003, 0x00000007, 0x0004003b,
        0x00000019, 0x0000001b, 0x00000003, 0x00040020, 0x0000001c, 0x00000001, 0x00000007, 0x0004003b,
        0x0000001c, 0x0000001d, 0x00000001, 0x00050036, 0x00000002, 0x00000004, 0x00000000, 0x00000003,
        0x000200f8, 0x00000005, 0x0004003d, 0x00000010, 0x00000013, 0x00000012, 0x00050051, 0x00000006,
        0x00000015, 0x00000013, 0x00000000, 0x00050051, 0x00000006, 0x00000016, 0x00000013, 0x00000001,
        0x00050051, 0x00000006, 0x00000017, 0x00000013, 0x00000002, 0x00070050, 0x00000007, 0x00000018,
        0x00000015, 0x00000016, 0x00000017, 0x00000014, 0x00050041, 0x00000019, 0x0000001a, 0x0000000d,
        0x0000000f, 0x0003003e, 0x0000001a, 0x00000018, 0x0004003d, 0x00000007, 0x0000001e, 0x0000001d,
        0x0003003e, 0x0000001b, 0x0000001e, 0x000100fd, 0x00010038
    };
    const uint32_t shaderFragCode[] = {
        0x07230203, 0x00010600, 0x0008000b, 0x0000000d, 0x00000000, 0x00020011, 0x00000001, 0x0006000b,
        0x00000001, 0x4c534c47, 0x6474732e, 0x3035342e, 0x00000000, 0x0003000e, 0x00000000, 0x00000001,
        0x0007000f, 0x00000004, 0x00000004, 0x6e69616d, 0x00000000, 0x00000009, 0x0000000b, 0x00030010,
        0x00000004, 0x00000007, 0x00030003, 0x00000002, 0x000001cc, 0x00040005, 0x00000004, 0x6e69616d,
        0x00000000, 0x00050005, 0x00000009, 0x4374756f, 0x726f6c6f, 0x00000000, 0x00050005, 0x0000000b,
        0x67617266, 0x6f6c6f43, 0x00000072, 0x00040047, 0x00000009, 0x0000001e, 0x00000000, 0x00040047,
        0x0000000b, 0x0000001e, 0x00000000, 0x00020013, 0x00000002, 0x00030021, 0x00000003, 0x00000002,
        0x00030016, 0x00000006, 0x00000020, 0x00040017, 0x00000007, 0x00000006, 0x00000004, 0x00040020,
        0x00000008, 0x00000003, 0x00000007, 0x0004003b, 0x00000008, 0x00000009, 0x00000003, 0x00040020,
        0x0000000a, 0x00000001, 0x00000007, 0x0004003b, 0x0000000a, 0x0000000b, 0x00000001, 0x00050036,
        0x00000002, 0x00000004, 0x00000000, 0x00000003, 0x000200f8, 0x00000005, 0x0004003d, 0x00000007,
        0x0000000c, 0x0000000b, 0x0003003e, 0x00000009, 0x0000000c, 0x000100fd, 0x00010038
    };

    VkShaderModuleCreateInfo shaderInfo = {
        .sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
        .codeSize = sizeof(shaderVertCode),
        .pCode = shaderVertCode
    };

    VkShaderModule shaderVertModule, shaderFragModule;
    if (vkCreateShaderModule(T_DEVICE(app), &shaderInfo, &defCustomAllocator, &shaderVertModule)) {
        fu_error("Failed to create vertex shader module!\n");
        return false;
    }
    shaderInfo.codeSize = sizeof(shaderFragCode);
    shaderInfo.pCode = shaderFragCode;
    if (vkCreateShaderModule(T_DEVICE(app), &shaderInfo, &defCustomAllocator, &shaderFragModule)) {
        fu_error("Failed to create fragment shader module!\n");
        vkDestroyShaderModule(T_DEVICE(app), shaderVertModule, &defCustomAllocator);
        return false;
    }
    bool rev = false;
    VkPipelineLayoutCreateInfo layoutInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO
    };
    if (vkCreatePipelineLayout(T_DEVICE(app), &layoutInfo, &defCustomAllocator, &T_PIPELINE_LAYOUT(app))) {
        fu_error("Failed to create pipeline layout!\n");
        goto out1;
    }

    VkPipelineShaderStageCreateInfo vertShaderStageInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,
        .stage = VK_SHADER_STAGE_VERTEX_BIT,
        .module = shaderVertModule,
        .pName = "main",
    };

    VkPipelineShaderStageCreateInfo fragShaderStageInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,
        .stage = VK_SHADER_STAGE_FRAGMENT_BIT,
        .module = shaderFragModule,
        .pName = "main",
    };

    VkPipelineShaderStageCreateInfo shaderStages[] = { vertShaderStageInfo, fragShaderStageInfo };

    VkPipelineVertexInputStateCreateInfo vertexInputState = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO,
        .vertexBindingDescriptionCount = 1,
        .pVertexBindingDescriptions = t_vertex_get_binding()
    };
    vertexInputState.pVertexAttributeDescriptions = t_vertex_get_description(&vertexInputState.vertexAttributeDescriptionCount);

    VkPipelineInputAssemblyStateCreateInfo inputAssemblyState = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO,
        .topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST
    };

    // viewport
    VkPipelineViewportStateCreateInfo viewportState = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO,
        .viewportCount = 1,
        .scissorCount = 1
    };

    // rasterizer state
    VkPipelineRasterizationStateCreateInfo rasterizerState = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO,
        .polygonMode = VK_POLYGON_MODE_FILL,
        .cullMode = VK_CULL_MODE_NONE,
        .frontFace = VK_FRONT_FACE_CLOCKWISE,
        .lineWidth = 1.0f
    };

    // multisample state
    VkPipelineMultisampleStateCreateInfo multisampleState = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO,
        .rasterizationSamples = VK_SAMPLE_COUNT_1_BIT,
        .minSampleShading = 1.0f
    };

    // color blend state
    VkPipelineColorBlendAttachmentState colorBlendAttachment = {
        .blendEnable = VK_TRUE,
        .srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA,
        .dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA,
        .colorBlendOp = VK_BLEND_OP_ADD,
        .srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE,
        .dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO,
        .colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT
    };
    VkPipelineColorBlendStateCreateInfo colorBlendState = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO,
        .logicOp = VK_LOGIC_OP_COPY,
        .attachmentCount = 1,
        .pAttachments = &colorBlendAttachment
    };

    // dynamic state
    // While most of the pipeline state needs to be baked into the pipeline state, a limited amount of the state can actually be changed without recreating the pipeline at draw time.
    // Examples are the size of the viewport, line width and blend constants.
    // If you want to use dynamic state and keep these properties out, then you’ll have to fill in a VkPipelineDynamicStateCreateInfo structure like this:
    VkDynamicState dynamicStates[] = { VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR };
    VkPipelineDynamicStateCreateInfo dynamicState = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO,
        .dynamicStateCount = FU_N_ELEMENTS(dynamicStates),
        .pDynamicStates = dynamicStates
    };

    VkGraphicsPipelineCreateInfo createInfo = {
        .sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO,
        .stageCount = 2,
        .pStages = shaderStages,
        .pVertexInputState = &vertexInputState,
        .pInputAssemblyState = &inputAssemblyState,
        .pViewportState = &viewportState,
        .pRasterizationState = &rasterizerState,
        .pMultisampleState = &multisampleState,
        .pColorBlendState = &colorBlendState,
        .pDynamicState = &dynamicState,
        .layout = T_PIPELINE_LAYOUT(app),
        .renderPass = T_RENDER_PASS(app)
    };

    if (vkCreateGraphicsPipelines(T_DEVICE(app), VK_NULL_HANDLE, 1, &createInfo, &defCustomAllocator, &T_PIPELINE(app))) {
        fu_error("Failed to create graphics pipeline!\n");
        goto out2;
    }
    rev = true;
out2:
    t_vertex_binding_free((void*)vertexInputState.pVertexBindingDescriptions);
    t_vertex_description_free((void*)vertexInputState.pVertexAttributeDescriptions);
out1:
    vkDestroyShaderModule(T_DEVICE(app), shaderVertModule, &defCustomAllocator);
    vkDestroyShaderModule(T_DEVICE(app), shaderFragModule, &defCustomAllocator);
    return rev;
}

static bool t_app_init_pipeline__render_pass(TApp* app)
{
    VkAttachmentDescription colorAttachment = {
        .format = app->surface.format.format,
        .samples = VK_SAMPLE_COUNT_1_BIT,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR
    };

    VkAttachmentReference colorAttachmentRef = {
        .attachment = 0,
        .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL
    };
    // The index of the attachment in this array is directly referenced from the fragment shader with the layout(location = 0) out vec4 outColor directive!
    // The following other types of attachments can be referenced by a subpass:
    //     pInputAttachments: Attachments that are read from a shader
    //     pResolveAttachments: Attachments used for multisampling color attachments
    //     pDepthStencilAttachment: Attachment for depth and stencil data
    //     pPreserveAttachments: Attachments that are not used by this subpass, but for which the data must be preserved

    VkSubpassDescription subpass = {
        .pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS,
        .colorAttachmentCount = 1,
        .pColorAttachments = &colorAttachmentRef
    };

    VkSubpassDependency dependency = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT
    };

    VkRenderPassCreateInfo renderPassInfo = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
        .attachmentCount = 1,
        .pAttachments = &colorAttachment,
        .subpassCount = 1,
        .pSubpasses = &subpass,
        .dependencyCount = 1,
        .pDependencies = &dependency
    };

    if (vkCreateRenderPass(T_DEVICE(app), &renderPassInfo, &defCustomAllocator, &T_RENDER_PASS(app))) {
        fu_error("Failed to create render pass\n");
        return false;
    }
    return true;
}

static bool t_app_init_pipeline(TApp* app)
{
    if (t_app_init_pipeline__render_pass(app)) {
        return t_app_init_pipeline__graphics_pipeline(app);
    }
    return false;
}
//
//  swapchain

static void t_app_swapchain_cleanup(TApp* app)
{
    uint32_t i;
    for (i = 0; i < app->swapchain.imageCount; i++)
        vkDestroyImageView(T_DEVICE(app), T_SWAPCHAIN_IMAGES(app)[i].view, &defCustomAllocator);

    for (i = 0; i < app->drawing.framebufferCount; i++)
        vkDestroyFramebuffer(T_DEVICE(app), T_FRAMEBUFFER(app)[i], &defCustomAllocator);
    vkDestroySwapchainKHR(T_DEVICE(app), T_SWAPCHAIN(app), &defCustomAllocator);
    mi_free(T_SWAPCHAIN_IMAGES(app));
    app->drawing.framebufferCount = 0;
}

static void t_app_destroy_swapchain(TApp* app)
{
    for (uint32_t i = 0; i < app->swapchain.imageCount; i++)
        vkDestroyImageView(T_DEVICE(app), T_SWAPCHAIN_IMAGES(app)[i].view, &defCustomAllocator);
    vkDestroySwapchainKHR(T_DEVICE(app), T_SWAPCHAIN(app), &defCustomAllocator);
    mi_free(T_SWAPCHAIN_IMAGES(app));
}

static bool t_surface_update_detail(TApp* app);
static bool t_app_init_swapchain(TApp* app)
{
    t_surface_update_detail(app);
    if (~0U > app->surface.capabilities.currentExtent.width && ~0U > app->surface.capabilities.currentExtent.height)
        memcpy(&app->surface.extent, &app->surface.capabilities.currentExtent, sizeof(VkExtent2D));
    else {
        int width, height;
#ifdef FU_USE_GLFW
        glfwGetFramebufferSize(T_WINDOW(app), &width, &height);
#else
        SDL_Vulkan_GetDrawableSize(T_WINDOW(app), &width, &height);
#endif
        app->surface.extent.width = (uint32_t)fu_max(fu_min(width, app->surface.capabilities.maxImageExtent.width), app->surface.capabilities.minImageExtent.width);
        app->surface.extent.height = (uint32_t)fu_max(fu_min(height, app->surface.capabilities.maxImageExtent.height), app->surface.capabilities.minImageExtent.height);
        printf("%s\n", __func__);
    }
    printf("%s  width:%u height:%u\n", __func__, app->surface.extent.width, app->surface.extent.height);
    uint32_t imageCount = app->surface.capabilities.minImageCount + 1;
    if (0 < app->surface.capabilities.maxImageCount && imageCount > app->surface.capabilities.maxImageCount)
        imageCount = app->surface.capabilities.maxImageCount;

    VkSwapchainCreateInfoKHR createInfo = {
        .sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR,
        .surface = T_SURFACE(app),
        .minImageCount = imageCount,
        .imageFormat = app->surface.format.format,
        .imageColorSpace = app->surface.format.colorSpace,
        .imageExtent = app->surface.extent,
        .imageArrayLayers = 1,
        .imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT,
        .imageSharingMode = VK_SHARING_MODE_EXCLUSIVE,
        .preTransform = app->surface.capabilities.currentTransform,
        .compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR,
        .presentMode = app->surface.presentMode,
        .clipped = VK_TRUE
    };
    if (vkCreateSwapchainKHR(T_DEVICE(app), &createInfo, &defCustomAllocator, &T_SWAPCHAIN(app))) {
        fu_error("failed to create swapchain\n");
        return false;
    }

    vkGetSwapchainImagesKHR(T_DEVICE(app), T_SWAPCHAIN(app), &imageCount, NULL);
    VkImage* images = (VkImage*)mi_calloc(imageCount, sizeof(VkImage));
    T_SWAPCHAIN_IMAGES(app) = (TImage*)mi_calloc(imageCount, sizeof(TImage));
    VkImageViewCreateInfo viewInfo = {
        .sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
        .viewType = VK_IMAGE_VIEW_TYPE_2D,
        .format = app->surface.format.format,
        .subresourceRange = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .levelCount = 1,
            .layerCount = 1 }
    };
    vkGetSwapchainImagesKHR(T_DEVICE(app), T_SWAPCHAIN(app), &imageCount, images);
    for (uint32_t i = 0; i < imageCount; i++) {
        T_SWAPCHAIN_IMAGES(app)
        [i].image
            = viewInfo.image = fu_steal_pointer(&images[i]);
        if (vkCreateImageView(T_DEVICE(app), &viewInfo, &defCustomAllocator, &T_SWAPCHAIN_IMAGES(app)[i].view)) {
            fu_error("failed to create image view\n");
            mi_free(images);
            return false;
        }
    }
    app->swapchain.imageCount = imageCount;
    mi_free(images);
    return true;
}

static void t_app_swapchain_update(TApp* app)
{
#ifdef FU_USE_GLFW
    while (glfwGetWindowAttrib(T_WINDOW(app), GLFW_ICONIFIED)) {
        glfwWaitEvents();
    }
#else
    SDL_Event ev;
    while (SDL_GetWindowFlags(T_WINDOW(app)) & SDL_WINDOW_MINIMIZED) {
        SDL_WaitEvent(&ev);
    }
#endif
    vkDeviceWaitIdle(T_DEVICE(app));

    t_app_swapchain_cleanup(app);

    t_app_init_swapchain(app);
    t_app_init_buffers__framebuffers(app);
}
//
//  device

static void t_physical_device_free_queue_family(TPhysicalDevice* dev)
{
    if (!dev)
        return;
    mi_free(dev->queueFamilies);
    mi_free(dev->graphicsQueueFamilies);
    mi_free(dev->computeQueueFamilies);
    mi_free(dev->transferQueueFamilies);
}

static void t_physical_device_destroy(TPhysicalDevice* device)
{
    if (!device)
        return;
    t_physical_device_free_queue_family(device);
    mi_free(device->extensions);
}

static void t_physical_device_free(TPhysicalDevice* devices, uint32_t count)
{
    if (!(devices && count))
        return;
    for (uint32_t i = 0; i < count; i++) {
        t_physical_device_free_queue_family(&devices[i]);
    }
    mi_free(devices);
}

static void t_app_destroy_device(TApp* app)
{
    t_physical_device_destroy(&app->device.physicalDevice);
    vkDestroyDevice(T_DEVICE(app), &defCustomAllocator);
}

/** 枚举队列族 */
static bool t_physical_device_enumerate_queue_family(TPhysicalDevice* dev, VkSurfaceKHR surface)
{
    vkGetPhysicalDeviceQueueFamilyProperties(dev->physicalDevice, &dev->queueFamilyCount, NULL);
    if (!dev->queueFamilyCount) {
        fu_error("No queue family found\n");
        return false;
    }
    dev->queueFamilies = (TQueueFamilyProperties*)mi_calloc(dev->queueFamilyCount, sizeof(TQueueFamilyProperties));
    dev->graphicsQueueFamilies = (TQueueFamilyProperties*)mi_calloc(dev->queueFamilyCount, sizeof(TQueueFamilyProperties));
    dev->computeQueueFamilies = (TQueueFamilyProperties*)mi_calloc(dev->queueFamilyCount, sizeof(TQueueFamilyProperties));
    dev->transferQueueFamilies = (TQueueFamilyProperties*)mi_calloc(dev->queueFamilyCount, sizeof(TQueueFamilyProperties));
    vkGetPhysicalDeviceQueueFamilyProperties(dev->physicalDevice, &dev->queueFamilyCount, &dev->queueFamilies->properties);
    VkBool32 presentSupported;
    for (uint32_t i = 0; i < dev->queueFamilyCount; i++) {
        if (dev->queueFamilies[i].properties.queueFlags & VK_QUEUE_GRAPHICS_BIT)
            dev->graphicsQueueFamilies[dev->graphicsQueueFamilyCount++] = dev->queueFamilies[i];
        if (dev->queueFamilies[i].properties.queueFlags & VK_QUEUE_COMPUTE_BIT)
            dev->computeQueueFamilies[dev->computeQueueFamilyCount++] = dev->queueFamilies[i];
        if (dev->queueFamilies[i].properties.queueFlags & VK_QUEUE_TRANSFER_BIT)
            dev->transferQueueFamilies[dev->transferQueueFamilyCount++] = dev->queueFamilies[i];
        vkGetPhysicalDeviceSurfaceSupportKHR(dev->physicalDevice, i, surface, &presentSupported);
        dev->queueFamilies[i].presentSupported = presentSupported;
        dev->queueFamilies[i].index = i;
    }

    return true;
}

/** 枚举物理设备以及其队列族 */
static TPhysicalDevice* t_physical_device_enumerate(VkInstance instance, VkSurfaceKHR surface, uint32_t* count)
{
    vkEnumeratePhysicalDevices(instance, count, NULL);
    if (!*count) {
        fu_error("No GPU with Vulkan support found\n");
        return NULL;
    }
    VkPhysicalDevice* devices = (VkPhysicalDevice*)mi_calloc(*count, sizeof(VkPhysicalDevice));
    TPhysicalDevice* rev = (TPhysicalDevice*)mi_calloc(*count, sizeof(TPhysicalDevice));
    vkEnumeratePhysicalDevices(instance, count, devices);
    for (uint32_t i = 0; i < *count; i++) {
        rev[i].physicalDevice = fu_steal_pointer(&devices[i]);
        vkGetPhysicalDeviceFeatures(rev[i].physicalDevice, &rev[i].features);
        vkGetPhysicalDeviceProperties(rev[i].physicalDevice, &rev[i].properties);
        if (t_physical_device_enumerate_queue_family(&rev[i], surface))
            continue;
        fu_error("failed to enumerate queue family\n");
        mi_free(devices);
        mi_free(rev);
        return NULL;
    }
    mi_free(devices);
    return rev;
}

/** 物理设备打分 */
TPhysicalDevice* t_physical_device_rate(TPhysicalDevice* devs, uint32_t count)
{
    if (!(devs && count))
        return NULL;
    VkBool32* fp;
    uint32_t currScore, bestScore = 0, bestDevice = 0, i, j;
    const uint32_t featureCount = sizeof(VkPhysicalDeviceFeatures) / sizeof(VkBool32);
    for (i = 0; i < count; i++) {
        if (!(devs[i].graphicsQueueFamilyCount && devs[i].queueFamilies[0].presentSupported))
            continue;
        fp = (VkBool32*)&devs[i].features;
        if (VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU == devs[i].properties.deviceType)
            currScore = 1000;
        else
            currScore = 0;
        for (j = 0; j < featureCount; j++) {
            if (fp[j])
                currScore += 1;
        }
        currScore *= 100;
        currScore += devs[i].properties.limits.maxBoundDescriptorSets;
        currScore += devs[i].properties.limits.maxComputeSharedMemorySize;
        currScore += devs[i].properties.limits.maxImageArrayLayers;
        currScore += devs[i].properties.limits.maxImageDimension2D;
        currScore += devs[i].properties.limits.maxImageDimensionCube;

        if (currScore > bestScore) {
            bestScore = currScore;
            bestDevice = i;
        }
    }
    return &devs[bestDevice];
}

static int t_physical_device_select_queue(TPhysicalDevice* dev)
{
    TQueueFamilyProperties* queueFamilyProperties;
    for (uint32_t i = 0; i < dev->queueFamilyCount; i++) {
        queueFamilyProperties = &dev->queueFamilies[i];
        if (!queueFamilyProperties->presentSupported)
            continue;
        if (!(queueFamilyProperties->properties.queueFlags & VK_QUEUE_GRAPHICS_BIT))
            continue;
        if (!(queueFamilyProperties->properties.queueFlags & VK_QUEUE_COMPUTE_BIT))
            continue;
        return i;
    }
    return -1;
}

/** 枚举并检查物理设备支持的扩展 */
static int t_physical_device_check_support_extension(TPhysicalDevice* dev, const char* const* const names, uint32_t count)
{
    vkEnumerateDeviceExtensionProperties(dev->physicalDevice, NULL, &dev->extensionCount, NULL);
    if (!dev->extensionCount) {
        fu_error("failed to enumerate device extension properties\n");
        return 0;
    }
    dev->extensions = (VkExtensionProperties*)mi_calloc(dev->extensionCount, sizeof(VkExtensionProperties));
    vkEnumerateDeviceExtensionProperties(dev->physicalDevice, NULL, &dev->extensionCount, dev->extensions);
    for (uint32_t i = 0, j; i < count; i++) {
        for (j = 0; j < dev->extensionCount; j++) {
            if (!strcmp(names[i], dev->extensions[j].extensionName))
                break;
        }
        if (j >= dev->extensionCount)
            return i;
    }
    return -1;
}

/** 物理设备复制构造 */
static void t_physical_device_init_with(TPhysicalDevice* target, TPhysicalDevice* source)
{
    memcpy(target, source, sizeof(TPhysicalDevice));
    target->queueFamilies = (TQueueFamilyProperties*)fu_memdup(source->queueFamilies, sizeof(TQueueFamilyProperties) * source->queueFamilyCount);
    target->graphicsQueueFamilies = (TQueueFamilyProperties*)fu_memdup(source->graphicsQueueFamilies, sizeof(TQueueFamilyProperties) * source->graphicsQueueFamilyCount);
    target->computeQueueFamilies = (TQueueFamilyProperties*)fu_memdup(source->computeQueueFamilies, sizeof(TQueueFamilyProperties) * source->computeQueueFamilyCount);
    target->transferQueueFamilies = (TQueueFamilyProperties*)fu_memdup(source->transferQueueFamilies, sizeof(TQueueFamilyProperties) * source->transferQueueFamilyCount);
}

static bool t_surface_update_detail(TApp* app)
{
    // TSurfaceDetail* detail = t_physical_device_enumerate_surface_detail(&app->device.physicalDevice, T_SURFACE(app));
    TSurfaceDetail* detail = (TSurfaceDetail*)mi_zalloc(sizeof(TSurfaceDetail));
    vkGetPhysicalDeviceSurfaceCapabilitiesKHR(T_PHYSICAL_DEVICE(app), T_SURFACE(app), &detail->capabilities);
    vkGetPhysicalDeviceSurfaceFormatsKHR(T_PHYSICAL_DEVICE(app), T_SURFACE(app), &detail->formatCount, NULL);
    vkGetPhysicalDeviceSurfacePresentModesKHR(T_PHYSICAL_DEVICE(app), T_SURFACE(app), &detail->presentModeCount, NULL);
    if (!(detail->formatCount && detail->presentModeCount)) {
        fu_error("Failed to query swapchain details!\n");
        mi_free(detail);
        return false;
    }
    detail->format = (VkSurfaceFormatKHR*)mi_calloc(detail->formatCount, sizeof(VkSurfaceFormatKHR));
    detail->presentMode = (VkPresentModeKHR*)mi_calloc(detail->presentModeCount, sizeof(VkPresentModeKHR));
    vkGetPhysicalDeviceSurfaceFormatsKHR(T_PHYSICAL_DEVICE(app), T_SURFACE(app), &detail->formatCount, detail->format);
    vkGetPhysicalDeviceSurfacePresentModesKHR(T_PHYSICAL_DEVICE(app), T_SURFACE(app), &detail->presentModeCount, detail->presentMode);

    memcpy(&app->surface.capabilities, &detail->capabilities, sizeof(VkSurfaceCapabilitiesKHR));
    memcpy(&app->surface.format, detail->format, sizeof(VkSurfaceFormatKHR));
    app->surface.presentMode = VK_PRESENT_MODE_FIFO_KHR;
    for (uint32_t i = 0; i < detail->formatCount; i++) {
        if (VK_COLOR_SPACE_SRGB_NONLINEAR_KHR == detail->format[i].colorSpace && VK_FORMAT_R8G8B8A8_SRGB == detail->format[i].format) {
            memcpy(&app->surface.format, &detail->format[i], sizeof(VkSurfaceFormatKHR));
            break;
        }
    }
    for (uint32_t i = 0; i < detail->presentModeCount; i++) {
        if (VK_PRESENT_MODE_MAILBOX_KHR == detail->presentMode[i]) {
            app->surface.presentMode = VK_PRESENT_MODE_MAILBOX_KHR;
            break;
        }
    }
    // t_physical_device_surface_detail_free(detail);
    mi_free(detail->format);
    mi_free(detail->presentMode);
    mi_free(detail);
    return true;
}

static bool t_app_init_device(TApp* app)
{
    const char* const defDeviceExtensions[] = {
        VK_KHR_SWAPCHAIN_EXTENSION_NAME
    };
    const char* const defLayers[] = {
        "VK_LAYER_KHRONOS_validation"
    };
    uint32_t deviceCount = 0;
    TPhysicalDevice* devices = t_physical_device_enumerate(app->instance, T_SURFACE(app), &deviceCount);
    if (!(devices && deviceCount))
        return false;
    bool rev = false;
    TPhysicalDevice* selectedDevice = t_physical_device_rate(devices, deviceCount);
    int queueIndex = t_physical_device_select_queue(selectedDevice);
    if (0 > queueIndex) {
        fu_error("Failed to find suitable queue family\n");
        goto out;
    }
    int i = t_physical_device_check_support_extension(selectedDevice, defDeviceExtensions, FU_N_ELEMENTS(defDeviceExtensions));
    if (0 <= i) {
        fu_error("Device does not support extension: %s\n", defDeviceExtensions[i]);
        goto out;
    }
    const float queuePriority = 1.0f;
    VkDeviceQueueCreateInfo queueCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
        .queueFamilyIndex = queueIndex,
        .queueCount = 1,
        .pQueuePriorities = &queuePriority
    };
    VkPhysicalDeviceFeatures deviceFeatures = {
        .robustBufferAccess = VK_TRUE,
        .samplerAnisotropy = VK_TRUE
    };
    VkDeviceCreateInfo createInfo = {
        .sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
        .queueCreateInfoCount = 1,
        .pQueueCreateInfos = &queueCreateInfo,
        .enabledLayerCount = FU_N_ELEMENTS(defLayers),
        .ppEnabledLayerNames = defLayers,
        .enabledExtensionCount = FU_N_ELEMENTS(defDeviceExtensions),
        .ppEnabledExtensionNames = defDeviceExtensions,
        .pEnabledFeatures = &deviceFeatures
    };
    if (vkCreateDevice(selectedDevice->physicalDevice, &createInfo, &defCustomAllocator, &T_DEVICE(app))) {
        fu_error("Failed to create logical device\n");
        goto out;
    }

    vkGetDeviceQueue(T_DEVICE(app), queueIndex, 0, &T_QUEUE(app));
#ifdef FU_USE_GLAD
    if (!gladLoaderLoadVulkan(app->instance, selectedDevice->physicalDevice, T_DEVICE(app))) {
        fu_error("failed to load vulkan");
        return false;
    }
#endif
    t_physical_device_init_with(&app->device.physicalDevice, selectedDevice);
    app->device.queueFamilyIndex = queueIndex;
    rev = true;
out:
    t_physical_device_free(devices, deviceCount);
    return rev;
}

//
//  surface
#ifdef FU_USE_GLFW
static void _app_key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

static void _app_resize_callback(GLFWwindow* window, int width, int height)
{
    TApp* app = (TApp*)glfwGetWindowUserPointer(window);
    app->swapchain.outOfDate = false;
}

static void t_app_destroy_surface(TApp* app)
{
    vkDestroySurfaceKHR(app->instance, app->surface.surface, &defCustomAllocator);
    glfwDestroyWindow(app->surface.window);
    glfwTerminate();
}

static bool t_app_init_surface(TApp* app)
{
    glfwInit();
    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
    app->surface.window = glfwCreateWindow(DEF_WIN_WIDTH, DEF_WIN_HEIGHT, "Vulkan Test Triangle", NULL, NULL);
    if (!app->surface.window) {
        fu_error("failed to create window\n");
        return false;
    }
    if (glfwCreateWindowSurface(app->instance, app->surface.window, &defCustomAllocator, &app->surface.surface)) {
        fu_error("Failed to create window surface\n");
        return false;
    }
    glfwSetKeyCallback(T_WINDOW(app), _app_key_callback);
    glfwSetFramebufferSizeCallback(T_WINDOW(app), _app_resize_callback);
    glfwSetWindowUserPointer(T_WINDOW(app), app);
    return true;
}
#else
static void t_app_destroy_surface(TApp* app)
{
    vkDestroySurfaceKHR(app->instance, app->surface.surface, NULL);
    SDL_DestroyWindow(T_WINDOW(app));
    SDL_Quit();
}

static bool t_app_init_surface(TApp* app)
{
    if (SDL_Init(SDL_INIT_VIDEO)) {
        fu_error("Failed to init SDL: %s\n", SDL_GetError());
        return false;
    }
    SDL_Vulkan_LoadLibrary(NULL);
    T_WINDOW(app) = SDL_CreateWindow("Vulkan Test Triangle", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, DEF_WIN_WIDTH, DEF_WIN_HEIGHT, SDL_WINDOW_VULKAN | SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    if (!T_WINDOW(app)) {
        fu_error("failed to create window\n");
        return false;
    }

    if (!SDL_Vulkan_CreateSurface(T_WINDOW(app), app->instance, &T_SURFACE(app))) {
        fu_error("Failed to create window surface: %s\n", SDL_GetError());
        return false;
    }

    SDL_SetWindowData(T_WINDOW(app), "usd", app);
    return true;
}
#endif

//
//  instance
static VKAPI_ATTR VkBool32 VKAPI_CALL _tvk_debug_cb(VkDebugUtilsMessageSeverityFlagBitsEXT severity, VkDebugUtilsMessageTypeFlagsEXT type, const VkDebugUtilsMessengerCallbackDataEXT* cbd, void* usd)
{
    static char buff[120];
    memset(buff, 0, sizeof(buff));
    if (VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT & type)
        sprintf(buff, "%s[General]", buff);
    if (VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT & type)
        sprintf(buff, "%s[Validation]", buff);
    if (VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT & type)
        sprintf(buff, "%s[Performance]", buff);
    if (VK_DEBUG_UTILS_MESSAGE_TYPE_DEVICE_ADDRESS_BINDING_BIT_EXT & type)
        sprintf(buff, "%s[Device Address Binding]", buff);
    if (VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT == severity) {
        fu_error("%s%s\n", buff, cbd->pMessage);
        return VK_FALSE;
    }
    if (VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT == severity) {
        fu_warning("%s%s\n", buff, cbd->pMessage);
        return VK_FALSE;
    }
    if (VK_DEBUG_UTILS_MESSAGE_SEVERITY_INFO_BIT_EXT == severity) {
        fu_info("%s%s\n", buff, cbd->pMessage);
        return VK_FALSE;
    }
    fprintf(stdout, "%s%s\n", buff, cbd->pMessage);
    return VK_FALSE;
}

static void t_app_destroy_instance(TApp* app)
{
    vkDestroyDebugUtilsMessengerEXT(app->instance, app->debugger, &defCustomAllocator);
    vkDestroyInstance(app->instance, &defCustomAllocator);
#ifdef FU_USE_GLAD
    gladLoaderUnloadVulkan();
#endif
}

static bool t_app_init_instance(TApp* app)
{
    const char* const defInstanceExtensions[] = {
        VK_KHR_SURFACE_EXTENSION_NAME,
        VK_EXT_DEBUG_UTILS_EXTENSION_NAME,
#ifdef VK_USE_PLATFORM_WIN32_KHR
        VK_KHR_WIN32_SURFACE_EXTENSION_NAME,
#elif defined(VK_USE_PLATFORM_XCB_KHR)
        VK_KHR_XCB_SURFACE_EXTENSION_NAME,
#elif defined(VK_USE_PLATFORM_WAYLAND_KHR)
        VK_KHR_WAYLAND_SURFACE_EXTENSION_NAME,
#endif
    };
    const char* const defLayers[] = {
        "VK_LAYER_KHRONOS_validation"
    };
    VkApplicationInfo appInfo = {
        .sType = VK_STRUCTURE_TYPE_APPLICATION_INFO,
        .pApplicationName = "Vulkan Test Triangle",
        .applicationVersion = VK_MAKE_VERSION(0, 0, 1),
        .pEngineName = "Vulkan Test Engine",
        .engineVersion = VK_MAKE_VERSION(0, 0, 1),
        .apiVersion = VK_API_VERSION_1_3
    };

    VkDebugUtilsMessengerCreateInfoEXT debuggerInfo = {
        .sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT,
        .messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_VERBOSE_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT,
        .messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT,
        .pfnUserCallback = _tvk_debug_cb
    };

    VkInstanceCreateInfo createInfo = {
        .sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
        .pNext = &debuggerInfo,
        .pApplicationInfo = &appInfo,
        .enabledLayerCount = FU_N_ELEMENTS(defLayers),
        .ppEnabledLayerNames = defLayers,
        .enabledExtensionCount = FU_N_ELEMENTS(defInstanceExtensions),
        .ppEnabledExtensionNames = defInstanceExtensions
    };
#ifdef FU_USE_GLAD
    if (!gladLoaderLoadVulkan(NULL, NULL, NULL)) {
        fu_error("failed to load vulkan");
        return false;
    }
#endif
    if (vkCreateInstance(&createInfo, &defCustomAllocator, &app->instance)) {
        fu_error("failed to create vulkan instance");
        return false;
    }

#ifdef FU_USE_GLAD
    if (!gladLoaderLoadVulkan(app->instance, NULL, NULL)) {
        fu_error("failed to load vulkan");
        return false;
    }
#else
    tvk_fns_init_instance(app->instance);
#endif
    if (vkCreateDebugUtilsMessengerEXT(app->instance, &debuggerInfo, &defCustomAllocator, &app->debugger)) {
        fu_warning("failed to create vulkan debug messenger");
    }
    return true;
}

static void t_app_free(TApp* app)
{
    t_app_destroy_sync(app);
    t_app_destroy_buffers(app);
    t_app_destroy_pipeline(app);
    t_app_destroy_swapchain(app);
    t_app_destroy_device(app);
    t_app_destroy_surface(app);
    t_app_destroy_instance(app);
    mi_free(app);
};

static TApp* t_app_new()
{
    TApp* app = (TApp*)mi_zalloc(sizeof(TApp));
    if (!t_app_init_instance(app))
        goto out;
    if (!t_app_init_surface(app))
        goto out;
    if (!t_app_init_device(app))
        goto out;
    if (!t_app_init_swapchain(app))
        goto out;
    if (!t_app_init_pipeline(app))
        goto out;
    if (!t_app_init_buffers(app))
        goto out;
    if (!t_app_init_sync(app))
        goto out;
    return app;
out:
    t_app_free(app);
    return NULL;
};

static void t_app_draw(TApp* app)
{
    static uint32_t imageIndex, frameIndex = 0;
    vkWaitForFences(T_DEVICE(app), 1, &app->sync.inFlight[frameIndex], VK_TRUE, ~0U);
    VkResult rev = vkAcquireNextImageKHR(T_DEVICE(app), T_SWAPCHAIN(app), ~0U, app->sync.imageAvailable[frameIndex], VK_NULL_HANDLE, &imageIndex);
    if (rev) {
        if (VK_ERROR_OUT_OF_DATE_KHR == rev) {
            app->swapchain.outOfDate = true;
            return;
        }
        if (VK_SUBOPTIMAL_KHR != rev) {
            fu_error("Failed to acquire swapchain image\n");
            return;
        }
        fu_warning("swapchain suboptiomal\n");
    }

    VkCommandBuffer cmdf = T_CMD_BUFF(app)[frameIndex];
    vkResetFences(T_DEVICE(app), 1, &app->sync.inFlight[frameIndex]);
    vkResetCommandBuffer(cmdf, 0);
    if (!t_command_buffer_recording(app, cmdf, imageIndex)) {
        fu_error("Failed to record command buffer\n");
        return;
    }

    VkSemaphore waitSemaphores[] = { app->sync.imageAvailable[frameIndex] };
    VkSemaphore signalSemaphores[] = { app->sync.renderFinished[frameIndex] };
    VkPipelineStageFlags waitStages[] = { VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT };
    VkSubmitInfo submitInfo = {
        .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .waitSemaphoreCount = 1,
        .pWaitSemaphores = waitSemaphores,
        .pWaitDstStageMask = waitStages,
        .commandBufferCount = 1,
        .pCommandBuffers = &cmdf,
        .signalSemaphoreCount = 1,
        .pSignalSemaphores = signalSemaphores
    };
    if (vkQueueSubmit(T_QUEUE(app), 1, &submitInfo, app->sync.inFlight[frameIndex])) {
        fu_error("Failed to submit command buffer\n");
        return;
    }
    VkSwapchainKHR swapchains[] = { T_SWAPCHAIN(app) };
    VkPresentInfoKHR presentInfo = {
        .sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,
        .waitSemaphoreCount = 1,
        .pWaitSemaphores = signalSemaphores,
        .swapchainCount = 1,
        .pSwapchains = swapchains,
        .pImageIndices = &imageIndex
    };
    rev = vkQueuePresentKHR(T_QUEUE(app), &presentInfo);
    if (rev) {
        if (VK_ERROR_OUT_OF_DATE_KHR == rev || VK_SUBOPTIMAL_KHR == rev)
            app->swapchain.outOfDate = true;
        else {
            fu_error("Failed to present command buffer\n");
        }
    }
    frameIndex = (frameIndex + 1) % app->swapchain.imageCount;
}

static bool t_app_check_and_exchange(TApp* app, const bool next)
{
    const bool prev = app->swapchain.outOfDate;
    if (prev != next)
        app->swapchain.outOfDate = next;
    return prev;
}

static void t_app_run(TApp* app)
{
#ifdef FU_USE_GLFW
    while (!glfwWindowShouldClose(app->surface.window)) {
        glfwPollEvents();
        t_app_draw(app);
        if (t_app_check_and_exchange(app, false))
            t_app_swapchain_update(app);
    }
#else
    SDL_Event ev;
    bool running = true;
    do {
        while (SDL_PollEvent(&ev)) {
            if (SDL_QUIT == ev.type) {
                running = false;
                break;
            }
            if (SDL_WINDOWEVENT == ev.type) {
                if (SDL_WINDOWEVENT_CLOSE == ev.window.event) {
                    running = false;
                    break;
                }
                if (SDL_WINDOWEVENT_RESIZED == ev.window.event || SDL_WINDOWEVENT_RESTORED == ev.window.event) {
                    app->swapchain.outOfDate = true;
                }
            }
        }
        t_app_draw(app);
        if (t_app_check_and_exchange(app, false))
            t_app_swapchain_update(app);
    } while (running);
#endif
    vkDeviceWaitIdle(T_DEVICE(app));
}

int main(void)
{
    TApp* app = t_app_new();
    if (!app)
        return 1;
    t_app_run(app);
    t_app_free(app);
    printf("bye");
    return 0;
}