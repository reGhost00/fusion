#pragma once
#include <mimalloc.h>
#include <stddef.h>

#define FU_LIKELY(expr) __builtin_expect(!!(expr), 1)
#define FU_UNLIKELY(expr) __builtin_expect(!!(expr), 0)

#ifdef __cplusplus
extern "C" {
#endif

void* fu_malloc(size_t size);
void* fu_malloc0(size_t size);
void* fu_malloc_n(size_t count, size_t size);
void* fu_malloc0_n(size_t count, size_t size);
void* fu_realloc(void* p, size_t size);
void fu_free(void* p);

static inline void* fu_steal_pointer(void* pp)
{
    void** ptr = (void**)pp;
    void* ref;

    ref = *ptr;
    *ptr = NULL;

    return ref;
}

typedef void (*FUNotify)(void* usd);
#define fu_steal_pointer(pp) ((typeof(*pp))(fu_steal_pointer)(pp))
void fu_clear_pointer(void** pp, FUNotify destroy);

void* fu_memdup(const void* p, size_t size);
char* fu_strdup(const char* src);
char* fu_strndup(const char* str, size_t n);
char* fu_strnfill(size_t length, char ch);
char* fu_strdup_printf(const char* format, ...);

#ifdef __cplusplus
}
#endif